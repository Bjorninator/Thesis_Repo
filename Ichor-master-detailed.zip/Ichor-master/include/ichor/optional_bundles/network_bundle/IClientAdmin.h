#pragma once

#include <ichor/Service.h>

namespace Ichor {
    class IClientAdmin {
    protected:
        virtual ~IClientAdmin() = default;
    };
}