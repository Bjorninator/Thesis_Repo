//
// Created by oipo on 04-01-21.
//

#ifndef ICHOR_IENDPOINT_H
#define ICHOR_IENDPOINT_H

#endif //ICHOR_IENDPOINT_H
