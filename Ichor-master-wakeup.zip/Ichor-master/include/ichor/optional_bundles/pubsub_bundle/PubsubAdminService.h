#pragma once

#include <ichor/Service.h>
namespace Ichor {
    struct IPubsubAdminService {
    };

    struct IPubsubPublisherService {
    };

    struct IPubsubSubscriberService {
    };
}