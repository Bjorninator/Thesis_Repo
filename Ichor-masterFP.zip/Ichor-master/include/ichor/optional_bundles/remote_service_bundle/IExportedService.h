#pragma once

namespace Ichor {
    template <typename T>
    class IExportedService : T {
    public:

    };
}