---
name: Feature request
about: Create an issue that requests a feature or other improvement
title: ''
labels: ''
assignees: ''

---

**Description**
Describe the feature/change you request and why do you want it.

**Additional context**
Add any other context or screenshots about the feature request here.
